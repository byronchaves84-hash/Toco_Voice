const $=id=>document.getElementById(id);let settings={},socket=null,deferredPrompt=null,eventsSeen=0,audioQueue=[],speaking=false,customSoundUrls=[],appPassword='';
const DEFAULT_SOUNDS={subscriber:'/static/sounds/entrada_suscriptor.wav',visitor:'/static/sounds/entrada_visitante.wav',unknown:'/static/sounds/entrada_sin_verificar.wav'};
const fieldMap={platform:'platform',api_key:'apiKey',channel_id:'channelId',tiktok_username:'tiktokUsername',voice:'voice',read_comments:'readComments',speak_author:'speakAuthor',solo_message:'soloMessage',read_gifts:'readGifts',read_social_events:'readSocialEvents',join_alerts_enabled:'joinAlertsEnabled',join_notifications_enabled:'joinNotificationsEnabled',join_welcome_enabled:'joinWelcomeEnabled',join_welcome_template:'joinWelcomeTemplate',join_sound_volume:'joinSoundVolume',subscriber_sound:'subscriberSound',visitor_sound:'visitorSound',unknown_sound:'unknownSound'};const fields=Object.keys(fieldMap);
function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2600)}
function collect(){const o={...settings};for(const key of fields){const el=$(fieldMap[key]);if(!el)continue;o[key]=el.type==='checkbox'?el.checked:el.type==='range'?Number(el.value):el.value;}return o}
function populate(s){settings=s||{};for(const id of ['subscriberSound','visitorSound','unknownSound']){const el=$(id);const val=settings[id==='subscriberSound'?'subscriber_sound':id==='visitorSound'?'visitor_sound':'unknown_sound']||'';if(val&&!Array.from(el.options).some(o=>o.value===val)){const opt=document.createElement('option');opt.value=val;opt.textContent=val.split('/').pop();el.append(opt)}}for(const key of fields){const el=$(fieldMap[key]);if(!el||settings[key]===undefined)continue;if(el.type==='checkbox')el.checked=!!settings[key];else el.value=settings[key]}$('volumeValue').textContent=($('joinSoundVolume').value||75)+'%';togglePlatform();}
function togglePlatform(){const yt=$('platform').value==='YouTube LIVE';$('youtubeFields').classList.toggle('hidden',!yt);$('tiktokFields').classList.toggle('hidden',yt);$('platformPill').textContent=yt?'YOUTUBE LIVE':'TIKTOK LIVE'}
async function api(path,body){const r=await fetch(path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json','X-App-Password':appPassword}:{'X-App-Password':appPassword},body:body?JSON.stringify(body):undefined});let data={};try{data=await r.json()}catch{}if(!r.ok)throw new Error(data.detail||'Error de conexión');return data}
async function saveSettings(show=true){try{const data=await api('/api/settings',{settings:collect()});settings=data.settings;if(show){$('saveFeedback').textContent='Configuración guardada.';toast('Configuración guardada en el servidor.');setTimeout(()=>$('saveFeedback').textContent='',3000)}}catch(e){toast(e.message)}}
function status(s){$('statusLabel').textContent=s.status||'LISTO';$('statusDetail').textContent=s.detail||'';$('statusDot').className='status-dot'+(s.status==='CONECTADO'?' live':s.status==='ERROR'?' error':'');$('connectBtn').disabled=!!s.running;$('disconnectBtn').disabled=!s.running}
function addEvent(ev){if(ev.kind==='ENTRADA'&&ev.sound)playSound(ev.sound);if(!$('eventLog').children.length||$('eventLog').querySelector('.empty-state'))$('eventLog').innerHTML='';const node=document.createElement('div');node.className='event-item';const top=document.createElement('div');top.className='event-top';const kind=document.createElement('span');kind.className='event-kind';kind.textContent=ev.kind||'CHAT';const time=document.createElement('span');time.textContent=ev.time||new Date().toLocaleTimeString();top.append(kind,time);const author=document.createElement('b');author.textContent=ev.author||'Moorttys';const p=document.createElement('p');p.textContent=ev.text||'';node.append(top,author,p);$('eventLog').prepend(node);while($('eventLog').children.length>80)$('eventLog').lastChild.remove();eventsSeen++;$('eventCount').textContent=eventsSeen}
function playSound(key){if(!collect().join_alerts_enabled)return;const url=collect()[key+'_sound']||DEFAULT_SOUNDS[key]||DEFAULT_SOUNDS.unknown;const a=new Audio(url);a.volume=Math.max(0,Math.min(100,Number($('joinSoundVolume').value)))/100;a.play().catch(()=>toast('Toca la pantalla una vez para habilitar audio.'))}
function say(text,priority=false,sound=null){if(sound)playSound(sound);if(!text)return;audioQueue.push({text,priority});audioQueue.sort((a,b)=>Number(b.priority)-Number(a.priority));runSpeechQueue()}
const FEMALE_VOICE_HINTS=['dalia','elvira','laura','sabina','helena','paulina','monica','mónica','lucia','lucía','valentina','camila','sofia','sofía','andrea','ximena','julia','teresa','aria','female'];
function voiceLooksFemale(v){const n=(v.name||'').toLocaleLowerCase('es');return FEMALE_VOICE_HINTS.some(x=>n.includes(x));}
function voiceLabel(v){return `${v.name} · ${v.lang}${voiceLooksFemale(v)?' · Femenina':''}`;}
function refreshVoiceOptions(){
  if(!('speechSynthesis'in window))return;
  const select=$('voice');const previous=select.value||settings.voice||'es-MX-DaliaNeural';
  const voices=speechSynthesis.getVoices().filter(v=>/^es([-_]|$)/i.test(v.lang||''));
  if(!voices.length){$('voiceStatus').textContent='Cargando voces de español del dispositivo…';return;}
  voices.sort((a,b)=>Number(voiceLooksFemale(b))-Number(voiceLooksFemale(a))||a.lang.localeCompare(b.lang)||a.name.localeCompare(b.name));
  select.innerHTML='';
  for(const v of voices){const opt=document.createElement('option');opt.value=v.name;opt.textContent=voiceLabel(v);select.append(opt)}
  let chosen=voices.find(v=>v.name===previous);
  if(!chosen){const old=String(previous).toLowerCase();const alias=old.includes('elvira')?'elvira':old.includes('dalia')?'dalia':old.includes('jorge')?'jorge':old.includes('alvaro')||old.includes('álvaro')?'alvaro':'';if(alias)chosen=voices.find(v=>v.name.toLowerCase().includes(alias));}
  if(!chosen&&previous.toLowerCase().includes('dalia'))chosen=voices.find(voiceLooksFemale);
  if(!chosen)chosen=voices.find(voiceLooksFemale)||voices[0];
  if(chosen)select.value=chosen.name;
  const selected=voices.find(v=>v.name===select.value);
  $('voiceStatus').textContent=selected?(voiceLooksFemale(selected)?'Voz femenina disponible: ':'Voz disponible: ')+selected.name:'Selecciona una voz disponible.';
}
function selectedSpeechVoice(){
  const name=$('voice').value;
  return speechSynthesis.getVoices().find(v=>v.name===name)||null;
}
function runSpeechQueue(){
  if(speaking||!audioQueue.length)return;
  const item=audioQueue.shift();
  if(!('speechSynthesis'in window)){toast('Este navegador no admite voz del sistema.');return;}
  const voice=selectedSpeechVoice();
  if(!voice){toast('La voz seleccionada aún no está disponible. Espera a que carguen las voces o elige otra.');return;}
  speaking=true;
  const utter=new SpeechSynthesisUtterance(item.text);
  utter.voice=voice;utter.lang=voice.lang||'es-MX';utter.rate=1;
  utter.onend=()=>{speaking=false;runSpeechQueue()};
  utter.onerror=()=>{speaking=false;runSpeechQueue()};
  speechSynthesis.speak(utter);
}
function handleMessage(msg){if(msg.type==='initial'){populate(msg.settings);status(msg.state);(msg.chat||[]).slice(-40).forEach(addEvent)}else if(msg.type==='status')status(msg.state);else if(msg.type==='event')addEvent(msg.event);else if(msg.type==='speak')say(msg.text,msg.priority,msg.sound);else if(msg.type==='settings')populate(msg.settings)}
function connectSocket(){const proto=location.protocol==='https:'?'wss':'ws';socket=new WebSocket(`${proto}://${location.host}/ws${appPassword?'?password='+encodeURIComponent(appPassword):''}`);socket.onmessage=e=>{try{handleMessage(JSON.parse(e.data))}catch{}};socket.onclose=()=>setTimeout(connectSocket,2500);socket.onerror=()=>socket.close()}
$('platform').addEventListener('change',()=>{togglePlatform();saveSettings(false)});$('joinSoundVolume').addEventListener('input',()=> $('volumeValue').textContent=$('joinSoundVolume').value+'%');$('saveBtn').addEventListener('click',()=>saveSettings(true));$('connectBtn').addEventListener('click',async()=>{await saveSettings(false);try{await api('/api/connect',{});toast('Solicitud de conexión enviada.')}catch(e){toast(e.message)}});$('disconnectBtn').addEventListener('click',async()=>{try{await api('/api/disconnect',{});toast('Lector detenido.')}catch(e){toast(e.message)}});$('testVoice').addEventListener('click',()=>{if(!selectedSpeechVoice()){toast('Espera a que carguen las voces o selecciona una voz disponible.');return;}say('Hola, soy Tocolita. Estoy listo para leer los mensajes de tu directo.',true)});
$('voice').addEventListener('change',()=>{const v=selectedSpeechVoice();$('voiceStatus').textContent=v?(voiceLooksFemale(v)?'Voz femenina seleccionada: ':'Voz seleccionada: ')+v.name:'La voz seleccionada no está disponible.';saveSettings(false)});
if('speechSynthesis'in window){refreshVoiceOptions();speechSynthesis.addEventListener?.('voiceschanged',refreshVoiceOptions);window.addEventListener('load',()=>setTimeout(refreshVoiceOptions,300));}document.querySelectorAll('[data-sound]').forEach(b=>b.addEventListener('click',()=>playSound(b.dataset.sound)));$('clearLog').addEventListener('click',()=>{$('eventLog').innerHTML='<div class="empty-state">Registro limpiado. Los nuevos eventos aparecerán aquí.</div>';eventsSeen=0;$('eventCount').textContent='0'});
$('soundUpload').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;const fd=new FormData();fd.append('file',file);try{const r=await fetch('/api/upload-sound',{method:'POST',body:fd});const d=await r.json();if(!r.ok)throw new Error(d.detail||'No se pudo subir');customSoundUrls.push({url:d.url,name:d.filename});document.querySelectorAll('.sound-select').forEach(sel=>{const opt=document.createElement('option');opt.value=d.url;opt.textContent=d.filename;sel.append(opt)});toast('Sonido subido. Elige en la lista correspondiente.')}catch(err){toast(err.message)}e.target.value=''});
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/static/sw.js').catch(()=>{}));window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;$('installBtn').classList.remove('hidden')});$('installBtn').addEventListener('click',async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$('installBtn').classList.add('hidden')});
// Mobile browsers require a user gesture before audio playback. The first tap unlocks speech/audio.
document.addEventListener('pointerdown',()=>{if('speechSynthesis'in window){speechSynthesis.getVoices();refreshVoiceOptions()}},{once:true});
(async()=>{try{const auth=await api('/api/auth-required');if(auth.required){appPassword=sessionStorage.getItem('moorttys_pw')||prompt('Introduce la contraseña de Moorttys Voice:')||'';sessionStorage.setItem('moorttys_pw',appPassword)}const d=await api('/api/state');populate(d.settings);status(d.state);(d.chat||[]).slice(-40).forEach(addEvent)}catch(e){toast(e.message||'No se pudo cargar la configuración del servidor.')}connectSocket()})();
